

export class child{
    _id:string;
  
    date_of_birth:string;
    parentId:string;
    firstname: string;
    lastname: string;
    middlename: string;
}
