import {  RouteInfo } from './sidebar.metadata';

export const ROUTES: RouteInfo[] = [
    { path: 'main', title: 'Main Page', icon: 'reorder', class:''},
    { path: 'dashboard', title: 'Dashboard',  icon: 'dashboard', class: '' },
    { path: 'user-profile', title: 'User Profile',  icon:'person', class: '' },
    { path: 'collection', title: 'Collection Process', icon:'directions_walk', class:''}
];
