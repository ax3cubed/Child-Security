/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ParentFilterPipe } from './parentFilter.pipe';

describe('Pipe: ParentFilter', () => {
  it('create an instance', () => {
    let pipe = new ParentFilterPipe();
    expect(pipe).toBeTruthy();
  });
});