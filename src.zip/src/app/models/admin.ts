export class Admin {
   
    _id: string;
    
    password:string;
    username:string;
    email:string;
    firstName: string;
    middlename: string;
    lastName: string;
    //staffId:string;
    //todo- staff id, database to ensure security in the admin dashboard


}

   

