

export class helpers{
    _id:string;
    photo:ByteString;
    parent_id:string;
    helper_relationship:string;
    firstname: string;
    lastname: string;
    midlename: string;
}
