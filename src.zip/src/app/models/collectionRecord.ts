
export class collectionRecord{
    _id:string;
    picked_up_by:string;
    verified_by:string;
    parent_id: string;
    parent_verified: boolean;
    helper_influence: boolean;
    helper_id: string;
    helper_pick_up_time: string;
    helper_verified: boolean;
}